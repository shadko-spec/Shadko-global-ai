const PRODUCTS = [
  {
    "id": "ebook-business",
    "name": "Small Business Starter Guide",
    "type": "Digital eBook",
    "price": 9.99,
    "currency": "USD",
    "description": "A practical starter guide for planning, launching and growing a small online business.",
    "file": "downloads/small-business-starter-guide.pdf"
  },
  {
    "id": "ai-prompts",
    "name": "AI Business Prompt Pack",
    "type": "Digital Download",
    "price": 7.99,
    "currency": "USD",
    "description": "Ready-to-use AI prompts for marketing, content creation, customer service and business planning.",
    "file": "downloads/ai-business-prompt-pack.pdf"
  },
  {
    "id": "social-templates",
    "name": "Social Media Content Templates",
    "type": "Digital Template Pack",
    "price": 6.99,
    "currency": "USD",
    "description": "Editable content ideas and templates designed to help small businesses post consistently.",
    "file": "downloads/social-media-content-templates.pdf"
  },
  {
    "id": "finance-guide",
    "name": "Personal Finance & Budgeting Guide",
    "type": "Digital eBook",
    "price": 8.99,
    "currency": "USD",
    "description": "A simple guide to budgeting, saving, debt management and building better financial habits.",
    "file": "downloads/personal-finance-budgeting-guide.pdf"
  }
];
