const CART_KEY = "shadko_cart_v1";

function getCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; }
  catch (e) { return []; }
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
}

function addToCart(id) {
  const product = PRODUCTS.find(p => p.id === id);
  if (!product) return;
  const cart = getCart();
  const item = cart.find(i => i.id === id);
  if (item) item.qty += 1;
  else cart.push({id, qty: 1});
  saveCart(cart);
  alert(product.name + " added to cart.");
}

function removeFromCart(id) {
  saveCart(getCart().filter(i => i.id !== id));
  renderCart();
}

function clearCart() {
  localStorage.removeItem(CART_KEY);
  updateCartCount();
  renderCart();
}

function cartTotal() {
  return getCart().reduce((sum, item) => {
    const p = PRODUCTS.find(x => x.id === item.id);
    return sum + (p ? p.price * item.qty : 0);
  }, 0);
}

function updateCartCount() {
  const count = getCart().reduce((n, i) => n + i.qty, 0);
  document.querySelectorAll("[data-cart-count]").forEach(el => el.textContent = count);
}

function renderCart() {
  const box = document.getElementById("cart-items");
  if (!box) return;
  const cart = getCart();
  if (!cart.length) {
    box.innerHTML = "<p>Your cart is empty.</p>";
    document.getElementById("cart-total").textContent = "$0.00";
    return;
  }
  box.innerHTML = cart.map(item => {
    const p = PRODUCTS.find(x => x.id === item.id);
    return `<div class="cart-row">
      <div><strong>${p.name}</strong><br><small>${p.type} × ${item.qty}</small></div>
      <div>$${(p.price * item.qty).toFixed(2)}
      <button onclick="removeFromCart('${p.id}')">Remove</button></div>
    </div>`;
  }).join("");
  document.getElementById("cart-total").textContent = "$" + cartTotal().toFixed(2);
}

function checkout() {
  const cart = getCart();
  if (!cart.length) return alert("Your cart is empty.");
  const subject = encodeURIComponent("SHADKO Global Order Request");
  const body = encodeURIComponent(
    cart.map(i => {
      const p = PRODUCTS.find(x => x.id === i.id);
      return `${p.name} x ${i.qty} — $${(p.price*i.qty).toFixed(2)}`;
    }).join("\n") +
    `\n\nTotal: $${cartTotal().toFixed(2)}\n\nPlease send payment instructions and download access.`
  );
  window.location.href = `mailto:orders@shdmug.co.ke?subject=${subject}&body=${body}`;
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartCount();
  renderCart();
});